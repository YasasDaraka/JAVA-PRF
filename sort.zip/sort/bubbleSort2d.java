import java.util.Arrays;

class bubbleSort2d{
	public static void main(String[]args){
		
		int[] ar = {15, 4, 8, 54, 65,47,85,-1};
		
		System.out.println(Arrays.toString(ar));
		sort1D(ar);
		System.out.println(Arrays.toString(ar));
		
		int[][] br = {{15,12} , {2,4} , {8,2} , {-1,3}} ;
		
		System.out.println(Arrays.deepToString(br));
		sort2DRows(br);
		System.out.println(Arrays.deepToString(br));
		sort2DColumns(br);
		System.out.println(Arrays.deepToString(br));
	}
	
	public static void sort2DRows(int[][] arr){   
		for(int i=0; i<arr.length-1; i++){
			for(int j=0; j<arr.length-1; j++){
				if(arr[j][0]>arr[j+1][0]){ 	// According to rows[0]
					
					int temp1 = arr[j][0];
					int temp2 = arr[j][1];
					arr[j][0] = arr[j+1][0];
					arr[j][1] = arr[j+1][1];
					arr[j+1][0] = temp1;
					arr[j+1][1] = temp2;
				}
			}
		}
	}
		
	public static void sort2DColumns(int[][] arr){   
		for(int i=0; i<arr.length-1; i++){
			for(int j=0; j<arr.length-1; j++){
				if(arr[j][1]>arr[j+1][1]){   // According to columns [1]
					
					int temp1 = arr[j][0];
					int temp2 = arr[j][1];
					arr[j][0] = arr[j+1][0];
					arr[j][1] = arr[j+1][1];
					arr[j+1][0] = temp1;
					arr[j+1][1] = temp2;
				}
			}
		}
	}
	
	public static void sort1D(int[] arr){
		for(int i=0; i<arr.length-1; i++){
			for(int j=0; j<arr.length-1; j++){
				if(arr[j]>arr[j+1]){
					
					int temp = arr[j];
					arr[j] = arr[j+1];
					arr[j+1] = temp;
				}
			}
		}
	}
}
