import java.util.*;
class MaxValue{
	public static void main (String[]args){
		Scanner sc=new Scanner(System.in);
		System.out.print("Input marks 01 :");
		int m1= sc.nextInt();
		System.out.print("Input marks 02 :");
		int m2= sc.nextInt();
		System.out.print("Input marks 03 :");
		int m3= sc.nextInt();
	
		int max = m1; //////////
		if (m2>max){
			max = m2;
			}
		if (m3>max){
			max = m3;
			}
		System.out.print("max mark is :"+ max);
		
		
		
	}
}
