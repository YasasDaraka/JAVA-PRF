import java.util.*;
class SmallestPositiveNumber{
	public static void main (String[]args){
		Scanner sc = new Scanner(System.in);
		
		
		int num=1;
		for(int i=1;i<=10;i++){
			if(num%i==0){
				System.out.println(num);
			}else{
				i=0;
				num++;
			}
		}
		System.out.println(num);
		
	}
}
