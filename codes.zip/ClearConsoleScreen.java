import java.io.IOException;

public class ClearConsoleScreen{
    public  static void main (String [] args){
        System.out.println("Hello");
        cls();
    }

    public static void cls(){
        try{
			new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
        }catch(Exception E){
            System.out.println(E);
        }
    }
}
