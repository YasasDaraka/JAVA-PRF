//>>>>  https://xperti.io/blogs/formatting-with-printf-in-java/#:~:text=The%20printf%20method%20in%20Java,of%20the%20format()%20method.

class printFormating2{
	public static void main(String[] args){
		System.out.printf("%s%n", "hello world!");  // %s <-- String    %n <-- New Line
		System.out.printf("%S %n", "hello world!");
		System.out.printf("'%S' %n", "hello world!");
		
		System.out.printf ("'%20s' %n", "hello world!");
		System.out.printf ("'%-20s' %n", "hello world!");
		
		System.out.printf("'%10.5s' %n", "Hello World!");  //%x.ys, The number x defines the padding on the left and y is the number of characters in the string.
		
		System.out.printf("'%1.2f' %n", 12555.23565);
		
		System.out.printf("%f%n", 3.1423);
		System.out.printf("'%3.2f'%n", 3.1423);
		
		System.out.printf ("'%-20s' %n", "hello world!");
		System.out.printf ("'%-20s' %n", "hello world!");
		System.out.printf ("'%-20s' %n", "hello world!");
		
		int mark1=50;
		int mark2 =100;
		double m=55.568;
		System.out.println("+---------------------------------------+--------------+");
		System.out.printf("%s %11d %s %n","|Programming Fundamentals Marks \t: ",mark1,"|");
		System.out.printf("%s %11d %s %n","|Database Management System  Marks \t: ",mark1,"|");
		System.out.printf("%s %11d %s %n","|Total Marks \t\t\t\t: ",mark2,"|");
		System.out.printf("%s %11.2f %s %n","|Avg. Marks \t\t\t\t: ",m,"|");
		System.out.printf("%s %11.2f %s %n","|Rank \t\t\t\t\t: ",m,"|");
		System.out.println("+---------------------------------------+--------------+");
		
		
		System.out.println("+----------+----------+--------------------+------------+-----------+");
		System.out.printf("%-10s %-10s %-20s %-10s %-10s %s %n","|Rank","|ID","|Name","|Total marks","|Avg. marks","|");
		System.out.println("+----------+----------+--------------------+------------+-----------+");
		System.out.printf("%-10s %-10s %-20s %s %10d %s %9.2f %s %n","|1","|1","|Amal","|",10000,"|",44.55,"|");
		System.out.printf("%-10s %-10s %-20s %s %10d %s %9.2f %s %n","|1","|1","|Amal","|",60,"|",55.33,"|");
		System.out.println("+----------+----------+--------------------+------------+-----------+");
		
		System.out.println("+----------+--------------------+------------+-----------+");
		System.out.printf("%-10s %-20s %-10s %-10s %s %n","|ID","|Name","|  PRF marks","|DBMS marks","|");
		System.out.println("+----------+--------------------+------------+-----------+");
		System.out.printf("%-10s %-20s %s %10d %s %9.2f %s %n","|s001","|Amal","|",10000,"|",44.55,"|");
		System.out.printf("%-10s %-20s %s %10d %s %9.2f %s %n","|s001","|Amal","|",60,"|",55.33,"|");
		System.out.println("+----------+--------------------+------------+-----------+");
	}	
}
