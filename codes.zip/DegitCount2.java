import java.util.*;
class DegitCount2{
	public static void main (String []args){
		Scanner sc= new Scanner(System.in);
		
		System.out.print("Enter number : ");
		int num = sc.nextInt();
		
		int count = 0;
		
		while (num != 0){
			num= num/10;
			count +=1;
			}
		
		System.out.println("No of degits : " +count);
		
		
		}
	}
