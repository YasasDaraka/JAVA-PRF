// kasun miuranga
import java.util.Scanner;
class Day01Quizz{
	public static void main(String args[]){
	Scanner sc = new Scanner (System.in);
	
	System.out.print("Input monday tempreture \t: ");
	double d1 = sc.nextDouble();
	
	System.out.print("Input tuesday tempreture \t: ");
	double d2 = sc.nextDouble();
	
	System.out.print("Input wednesday tempreture \t: ");
	double d3 = sc.nextDouble();
	
	System.out.print("Input Thursday tempreture \t: ");
	double d4 = sc.nextDouble();
	
	System.out.print("Input friday tempreture \t: ");
	double d5 = sc.nextDouble();
	
	System.out.print("Input saturday tempreture \t: ");
	double d6 = sc.nextDouble();
	
	System.out.print("Input sunday tempreture \t: ");
	double d7 = sc.nextDouble();
	
	double total = d1+d2+d3+d4+d5+d6+d7;
	System.out.println("Weekdays average tempreture : " + (total/7));
	
	System.out.println(" Monday \t :"+ d1+"\n Tuesday \t :"+d2+ "\n Wednesday \t :"+d3+"\n Thursday \t :"+d4+"\n Friday \t :"+d5+"\n Staterday \t :"+d6+ "\n Sunday \t :" +d7);
	
	
	}
}
