import java.util.Scanner;
class amstronNum{
	public static void main (String args[]){
	Scanner sc = new Scanner(System.in);	
	
	int total=0;
	
	char ans='a';
	do{	System.out.print("Enter num : ");	
		int num= sc.nextInt();
		int x = num;
		
		while (x!=0){
		int d = x%10;
		total += d*d*d;
		x = x/10;
		}
		
		if (total == num){
			System.out.println("amstron");
			break;
			
		}else{
			//System.out.print("tot = "+total+ " num = "+num );

			System.out.println("not amstron");
			total = 0;
			System.out.print(" Do you want to try again ? y/n : ");
			ans= sc.next().charAt(0);
			}
			
	}while (ans=='y');
	}
}

