import java.util.*;
class awl{
	public static void main (String args[]){
		Scanner sc = new Scanner(System.in);
		char ans= 'y';
		int i=1;
		do {
			System.out.println("ganann ganna epa ("+i+")");
			i++;
			System.out.println("Thamath awlda ?  (y/n) " );
			ans = sc.next().charAt(0);
			}while (ans=='y');
			
		if (ans=='n'){
			System.out.println("Athi yanthan");
			}
		}
	}
