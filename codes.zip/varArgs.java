import java.util.*;
class varArgs{
	public static void main (String[]args){
		meth1();
		meth1(10,20,30,40);
		meth1(4,5,6);		
	}

	public static void meth1(int ... xr){   
		System.out.println(Arrays.toString(xr)); // print array
	}
}
