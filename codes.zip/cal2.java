import java.util.Scanner;
class cal2
{
	public static void main(String args[])
	{
		Scanner test = new Scanner(System.in);
		
		double no1,no2,mark;
		
		System.out.print(" Enter 1st number... ");
		no1 = test.nextDouble();

		System.out.print(" Enter 2nd number... ");
		no2 = test.nextDouble();
		
		System.out.println(" \n   Press ");
		System.out.println(" 0 for ALL \n 1 for Equal \n 2 for minus \n 3 for Devide \n 4 for Multiply \n 5 for Reminder ");

		mark = test.nextDouble();

		if(mark==0)
		{
			System.out.println(" Equal is = " +(no1+no2)+" \n Minus is = " +(no1-no2)+" \n Devid is = " +(no1/no2)+" \n Multiply is = " +(no1*no2)+" \n Reminder is = " +(no1%no2));
		}

		if(mark==1)
		{
			System.out.println(" Equal is = " +(no1+no2));
		}
		
		if(mark==2)
		{
			System.out.println(" Minus is = " +(no1-no2));
		}
		
		if(mark==3)
		{
			System.out.println(" Devid is = " +(no1/no2));
		}

		if(mark==4)
		{
			System.out.println(" Multiply is = " +(no1*no2));
		}
		
		if(mark==5)
		{
			System.out.println(" Reminder is = " +(no1%no2));
		}

		if(mark > 5)
		{
			System.out.println(" Error input ");
		}
		if(mark < 0)
		{
			System.out.println(" Error input ");
		}
	}
}