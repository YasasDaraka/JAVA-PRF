import java.util.*;	
class ExtendsArray{	
	public static int[] extendsArray(int[] xr) {
		int[] temp = new int[xr.length + 1];
		
		for(int i = 0; i < xr.length; i++) {
			temp[i] = xr[i];
		}
		return temp;
	}
	
	public static int[] storeData(int[] xr, int data) {
		xr = extendsArray(xr);
		xr[xr.length - 1] = data;
		return xr;
	}
	
	public static void main(String args[]){		
		int xr[] = new int[2];
		
		xr = storeData(xr, 10);
		System.out.println(Arrays.toString(xr));
	}
}
