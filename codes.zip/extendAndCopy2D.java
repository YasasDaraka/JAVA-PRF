import java.util.*;
class extendAndCopy2D{
	public static void main(String args[]){
		int[][] arr = new int[0][3];
		
		System.out.println(Arrays.deepToString(arr));
		System.out.println("Length is = "+ arr.length);
		
		arr = extendArray(arr);
		System.out.println(Arrays.deepToString(arr));
		System.out.println("Length is = "+ arr.length);
		
		arr = extendArray(arr);
		System.out.println(Arrays.deepToString(arr));
		System.out.println("Length is = "+ arr.length);

	}
	public static int[][] extendArray(int[][] arr){
		int[][] temp = new int[arr.length+1][3];
		temp = copyElements(arr,temp);
		arr = temp;
		return arr;
	}
	
	public static int[][] copyElements(int[][] arr, int[][] temp){
		for(int i=0; i<arr.length; i++){
			for(int j=0; j<arr[i].length; j++){
				temp[i][j]=arr[i][j];
			}
		}
		return temp;
	}
}
