import java.util.*;
class passwordLoop {
	public static void main (String [] args){
		Scanner sc = new Scanner(System.in);
		int pw =0;
		while (pw != 1234){
		System.out.print(" Enter Password : ");
		pw = sc.nextInt();
		
		if (pw==1234){
			System.out.println(" Sucsess");
			}else {
				System.out.println(" faild Try again");
				}
		}
	}
}
