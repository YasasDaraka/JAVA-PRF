
import java.util.Scanner;
class CharacterLoop{
public static void main(String []args){
		
		
	for ( char a ='A'; a<='Z'; a++){
	
		System.out.print(a);
		System.out.println(":"+(int)a);
	}
	}
}
