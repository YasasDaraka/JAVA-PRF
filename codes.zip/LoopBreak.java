import java.util.*;
class LoopBreak{
	public static void main (String [] args){
	Scanner sc = new Scanner (System.in);
	String fav = "kasun";
	String name = " ";
	
	for (int i = 0; i<5; i++){
		System.out.print( "Enter student name : ");
		name = sc.next();
		
		if (name .equals(fav)){
			System.out.print( name +" Loves you !");
			break;  // eka nathnam 5 k run wenoo
			}
		}
	
}
}
