class TypeCasting2{
	public static void main (String args[]){
		
		int a =10;
		double b=a; // wider conversion [forceless]
		
		System.out.println(b); // 10.0
		
		///////////////////////////////////////////////////
		
		double x =10.5;
		int y =5;
		y+=x;	// narrow conversion [forceless]   ... x=x+y;

		System.out.println(y); // 15
		
		//////////////////////////////////////////////////
		
		double c = 10.5;
		int d = (int) c;  // narrow casting (force)
		
		System.out.println(d); //10
		
		//////////////////////////////////////////////////
		
		char ch='A';
		System.out.println((int)ch); // 65   // wider casting (force)
		
		//-----------------
		
		int g = 5;
		int h = 2;
		double i; 
		
		i = g/h; 
		System.out.println(i); // 2.0
		
		i = (double)g/h; 
		System.out.println(i); // 2.5  // wider casting (force)

		i = g/(double)h; 
		System.out.println(i); // 2.5	// wider casting (force)	
		}
	}
