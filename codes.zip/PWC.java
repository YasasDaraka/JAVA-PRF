import java.util.*;

public class PWC{
	public static void main (String args[]){
	Random R = new Random();
	Scanner sc = new Scanner(System.in);
	
	System.out.print("Enter Your Password (2 numbers): ");
	int pw = sc.nextInt();
	int Cpw=0;
	
	while (pw != Cpw){
		Cpw = R.nextInt(100);
		System.out.println(Cpw);
		
		}
	if (pw == Cpw){
			System.out.println("Cracked , pw is =" +Cpw);
			}
}
}
