import java.util.*;
class GDC{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		
		int dividned=0 , diviser=0;
		
		System.out.print("Enter 1st integer : ");
		int num1=sc.nextInt();
		System.out.print("Enter 2nd integer : ");
		int num2=sc.nextInt();
		
		// devided and diviser select
		if (num1>num2){
			dividned = num1;
			diviser = num2;
			}
		else if(num2>num1){
			dividned = num2;
			diviser = num1;
			}
		else{
			dividned = num2;
			diviser = num1;
			}
		
		// dividned = diviser * quotient + reminder
		int quotient = 1;
		int reminder = 1;
		
		while (reminder!=0){
			quotient = dividned/diviser;
			reminder = dividned - (diviser*quotient);
			System.out.println(dividned+"="+diviser+"x"+quotient+"+"+reminder);
			dividned = diviser;
			if (reminder==0){break;}
			diviser = reminder;
			}
		System.out.println("GDC of "+num1+" and "+num2+" is = "+diviser);
	}
}
