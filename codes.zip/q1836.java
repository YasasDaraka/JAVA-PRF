import java.util.*;
class q1836{
	public static void main (String args[]){
		Scanner sc=new Scanner(System.in);
		System.out.print("input birth year : ");
		int year = sc.nextInt();
		
		int  digit = year%10;
		
		if (digit == 0){
			System.out.println("System error");
			}
		else if (digit == 9){
			System.out.println("You have 1 baby");
			}
		else if (digit == 1){
			System.out.println("You have 1 baby");
			}
		else{
			System.out.println("You have "+digit+" babies");
			}
		
		}
	}
