
public class TypeCasting {
	
	public static void main (String[] args) {
		
		 int a = 10;
		 double b = a; //wider conversion
		 
		 System.out.println(b);  // 10.0   
		 
		 int c = 5;
		 int d = 2;
		 double avg = (double) c / d;  // wider casting
		 
		 System.out.println(avg);	// 2.5 
		 
		 
		 double x = 10.123;
		 int y = 5;
		 y+=x;  //narrow conversion
		 System.out.println(y);	 // 15  
		 
		 
		 double g= 10.123;
		 int h = (int) g; //narrow casting
		 System.out.println(h);	 // 10 
		 
		 h = (byte) g;
		 System.out.println(h);  // compitible type ekakata assign karanna puluwan , variable eka hadapu type ekama wenna oona na
		 
		 
	}
	
}


