class PowerOfNumber{
	public static void main(String args[]){
		
		int base = 10, power=2;
		int ans=1;
		
		while(power!=0){
			ans = ans*base;
			//System.out.println(ans);
			power--;
			}
		System.out.println(ans);
	}
}
