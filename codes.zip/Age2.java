import java.util.Scanner;

class Age2{
	
	public static void main (String[]args){
		
		String name;
		int age;
		
		Scanner input1 = new Scanner(System.in);
		
		System.out.print(" Hello , What's your name? ... ");
		
		name = input1.next();
		
		System.out.println(" Hi "+ name + " :) ");
		System.out.print(" What's your age ? ... ");	
		
		Scanner input2 = new Scanner(System.in);
		
		age= input2.nextInt();
		
		System.out.println(name + "'s age is " + age);
		
		
	}



}


