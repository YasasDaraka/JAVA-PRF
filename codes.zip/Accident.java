import java.util.*;
class Accident {
	public static void main(String args[]) {
		Scanner sc= new Scanner(System.in);
		
		int[][] arr = new int[12][]; 
		arr[0]= new int[31];
		arr[1]= new int[28];
		arr[2]= new int[31];
		arr[3]= new int[30];
		arr[4]= new int[31];
		arr[5]= new int[30];
		arr[6]= new int[31];
		arr[7]= new int[31];
		arr[8]= new int[30];
		arr[9]= new int[31];
		arr[10]= new int[30];
		arr[11]= new int[31];
		
		int loop=1;
		while(loop==1){
			
		System.out.println("----SRI LANKA's DAILY ACCIDENTS----\n");
		System.out.println("1. Input data for a day");
		System.out.println("2. Total Accidents in a month");
		System.out.println("3. Maximum accident count of a day in a month");
		System.out.println("4. Input data for each month each day");
		System.out.println("5. Most Accidended month");
		System.out.println("6. Avarage of accidents on year");
		System.out.println("7. total of accident (months ending by the 31st)");
		System.out.println("8. the day that the minimum number of accidents count caught in a given month");
		System.out.println("9. display the accident count per day for a specific month in ascending order");
		System.out.println("10. month with the minimum accident caught ");
		System.out.println("11. exact count of accident caught days in a given month");
		System.out.println("12. average accident count for a given month");
		System.out.println("13. print accident counts in every month for the given day ");
		System.out.println("14. day with month that the maximum accident count was caught in the year");
		System.out.println("\npress 0 for terminate");
		System.out.println();
		
		System.out.print("Press one of above numbers :");
		int ans=sc.nextInt();

		switch (ans){
		case 0 : loop = 0; break;
		case 1 : inputGivenMonth(arr); break;
		case 2 : givenMonthTotAcc(arr);break;
		case 3 : givenMonthMaxAccDate(arr);break;
		case 4 : inputEachMonth(arr);break;
		case 5 : maxAccMonth(arr);break;
		case 6 : avgAccYear(arr);break;
		case 7 : tot31(arr);break;
		case 8 : minimumAccDay(arr);break;
		case 9 : sortAsc(arr);break;
		case 10 : minAccMonth(arr);break;
		case 11 : accCaugthDays(arr);break;
		case 12 : avgAccCount(arr);break;
		case 13 : contGivenDate(arr);break;
		case 14 : maximumDayMonth(arr);break;
		}
		if(loop==1){
			System.out.println("\npress 'r' to main menu \npress any key to terminate");
			char ans2 = sc.next().charAt(0);
			if (ans2=='r'){
				cls();
			}else{
				cls();
				System.out.println("ended");
				loop=0;
				}
		}
	}
	}
	
	public static void cls(){
        try{
			new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
        }catch(Exception E){
            System.out.println(E);
        }
    }
    
	public static void inputGivenMonth(int[][] arr) {
		cls();
		char ans=' ';
		System.out.println("\n(1)------Input data for a day---------");
		do{
			Scanner sc= new Scanner(System.in);
			System.out.print("Enter month : ");
			int month = sc.nextInt();
			System.out.print("Enter date : ");
			int date = sc.nextInt();
			System.out.print("Enter deth count : ");
			arr[month-1][date-1] = sc.nextInt();
			
			System.out.print(">>Do you input any values y/n : ");
			ans = sc.next().charAt(0);
			System.out.println();
		}
		while(ans!='n');
	}
	
	public static void givenMonthTotAcc(int[][] arr) {
		cls();
		Scanner sc= new Scanner(System.in);
		System.out.println("\n(2)-------Total Accidents in a month---------");
		System.out.print("Enter month : ");
		int month = sc.nextInt();
		
		int tot=0;
		for(int i=0; i<arr[month-1].length; i++){
			tot+= arr[month-1][i];
		}
		System.out.println("Total deth count in month : "+tot);

	}
	
	public static void givenMonthMaxAccDate(int[][] arr) {
		cls();
		Scanner sc= new Scanner(System.in);
		System.out.println("\n(3)------- Maximum accident count of a day in a month ---------");
		System.out.print("Enter month : ");
		int month = sc.nextInt();
		
		int max = arr[month-1][0];
		int maxDay =0;
		for(int i=0; i<arr[month-1].length; i++){
			if(max<arr[month-1][i]){
				max=arr[month-1][i];
				maxDay=i;
			}
		}
		System.out.println("Maximum Deths Day : "+(maxDay+1));
		System.out.println("Maximum Deths : "+max);
	}
	
	public static void inputEachMonth(int[][] arr) {
		cls();
		System.out.println("\n(4)------- Input data for each month each day ---------");
		Scanner sc= new Scanner(System.in);
		for(int i=0; i<arr.length; i++){
			for(int j=0; j<arr[i].length; j++){
				System.out.print("month"+(i+1)+" , date"+(j+1)+" Enter deth count : ");
				arr[i][j]=sc.nextInt();
			}
		}
	}
	
	public static void maxAccMonth(int[][] arr) {
		cls();
		System.out.println("\n(5)------- Most Accidended month ---------");
		int maxMonth=0;
		int monthTot=0;
		for(int i = 0; i<arr.length; i++){
			for(int j=0; j<arr[i].length; j++){
				int tot = 0;
				tot += arr[i][j];
				if(monthTot<tot){
					monthTot=tot;
					maxMonth=i;
				}
				
			}
		}
		System.out.println("month is :"+(maxMonth+1));
		System.out.println("Deth total is :"+monthTot);
	}
	
	public static void avgAccYear(int[][] arr) {
		cls();
		System.out.println("\n(6)------- Avarage of accidents on year ---------");
		int tot = 0;
		for(int i = 0; i<arr.length; i++){
			for(int j=0; j<arr[i].length; j++){
				tot += arr[i][j];
			}
		}
		System.out.println("total is : "+tot);
		System.out.println("Avarage is : "+(double)tot/12);
	}
	
	public static void tot31(int[][] arr) {
		cls();
		System.out.println("\n(7)------- total of accident (months ending by the 31st) ---------");
		int tot = 0;
		for(int i = 0; i<arr.length; i++){
			if(i==0||i==2||i==4||i==6||i==7||i==9||i==11) {
				for(int j=0; j<arr[i].length; j++){
					tot += arr[i][j];
				}
			}
		}
		System.out.println("total is : "+tot);
	}
	
	public static void minimumAccDay(int[][] arr) {
		cls();
		Scanner sc= new Scanner(System.in);
		System.out.println("\n(8)------- the day that the minimum number of accidents count caught in a given month ---------");
		System.out.print("Enter month : ");
		int month = sc.nextInt();
		
		int min = arr[month-1][0];
		int minDay =0;
		for(int i=0; i<arr[month-1].length; i++){
			if(min>arr[month-1][i]){
				min=arr[month-1][i];
				minDay=i;
			}
		}
		System.out.println("minimum Deths Day : "+(minDay+1));
		System.out.println("minimum Deths : "+min);
	}
	
	public static void sortAsc(int[][] arr) {
		cls();
		Scanner sc= new Scanner(System.in);
		System.out.println("\n(9)------- display the accident count per day for a specific month in ascending order---------");
		System.out.print("Enter month : ");
		int month = sc.nextInt();
		Arrays.sort(arr[month-1]);
		System.out.println(Arrays.toString(arr[month-1]));
	}
	
	public static void minAccMonth(int[][] arr) {
		cls();
		Scanner sc= new Scanner(System.in);
		System.out.println("\n(10)-------month with the minimum accident caught---------");
		int minMonth=0;
		int monthTot=arr[0][0];
		for(int i = 0; i<arr.length; i++){
			for(int j=0; j<arr[i].length; j++){
				int tot = 0;
				tot += arr[i][j];
				//System.out.println(tot);
				//System.out.println(monthTot);
				if(monthTot>=tot){
					monthTot=tot;
					minMonth=i;
				}
				
			}
		}
		System.out.println("month is :"+(minMonth+1));
		System.out.println("Deth total is :"+monthTot);
	}
	
	public static void accCaugthDays(int[][] arr) {
		cls();
		Scanner sc= new Scanner(System.in);
		System.out.println("\n(11)-------exact count of accident caught days in a given month---------");
		System.out.print("Enter month : ");
		int month = sc.nextInt();
		int count =0;
		for(int i =0; i<arr[month-1].length; i++){
			if(arr[month-1][i]!=0){
			count++;	
			//System.out.println(count);
			}
		}
		System.out.println("exact count of accident caught days : "+count);
	}
	
	public static void avgAccCount(int[][] arr) {
		cls();
		Scanner sc= new Scanner(System.in);
		System.out.println("\n(12)------- average accident count for a given month ---------");
		System.out.print("Enter month : ");
		int month = sc.nextInt();
		int count =0;
		for(int i =0; i<arr[month-1].length; i++){
			if(arr[month-1][i]!=0){
			count++;	
			//System.out.println(count);
			}
		}
		//System.out.println(arr[month-1].length);
		System.out.println("average accident count : "+((double)count/arr[month-1].length));
	}
	
	public static void contGivenDate(int[][] arr) {
		cls();
		Scanner sc= new Scanner(System.in);
		System.out.println("\n(13)-------print accident counts in every month for the given day ---------");
		System.out.print("Enter day : ");
		int day = sc.nextInt();
		for(int i = 0; i<arr.length; i++){
			System.out.print("month "+(i+1)+" : ");
			System.out.println(arr[i][day-1]);
		}
	}
	
	public static void maximumDayMonth(int[][] arr) {
		cls();
		Scanner sc= new Scanner(System.in);
		System.out.println("\n(14)-------day with month that the maximum accident count was caught in the year---------");
		
		int max = 0;
		int month = 0;
		int date = 0;
		for(int i = 0; i<arr.length; i++){
			for(int j=0; j<arr[i].length; j++){
					if(max<arr[i][j]){
						max=arr[i][j];
						month=i;
						date=j;
					}
			}
		}
		System.out.println("max is :"+max);
		System.out.println("month is :"+(month+1));
		System.out.println("day is :"+(date+1));
	}
}
