// (1)Scanner input
import java.util.Scanner;

class Scanner_test{
	
		public static void main (String args[]){
			
			// (2) Scanner setup process
			Scanner scannerName = new Scanner(System.in);
			
			char x = scannerName.next().charAt(0); // (3) Waiting for Keybord input
					
			System.out.println(x);
			
		}
		
}


			/*	String x = scannerName.next();
				String x = scannerName.nextLine();   
				int x = scannerName.nextInt();
				float x = scannerName.nextFloat();
				double x = scannerName.nextDouble();	
				char x = scannerName.next().charAt(0);			
			*/
